﻿using System;
using System.Collections.Generic;

namespace PersonalWork.Infrastructure.LocalDB;

public partial class ItemNumberGenerater
{
    public long FtoysItemNumber { get; set; }

    public long? BstitemNumber { get; set; }
}
