﻿using System;
using System.Collections.Generic;

namespace PersonalWork.Infrastructure.LocalDB;

public partial class Tempprice
{
    public long? ItemNumber { get; set; }

    public decimal? Sprice { get; set; }
}
