﻿using AutoMapper;
using MediatR;
using PersonalWork.Application.Abstractions.Repositories;
using PersonalWork.Infrastructure.LocalDB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalWork.Application.Queries.Products1.SearchProduct1
{
    public class SearchProduct1Handler : IRequestHandler<SearchProduct1Query, List<SearchProduct1Dto>>
    {
        public IUnitOfWork UnitOfWork;
        public IMapper Mapper;

        public SearchProduct1Handler(IUnitOfWork UnitOfWork, IMapper Mapper)
        {
            this.UnitOfWork = UnitOfWork;
            this.Mapper = Mapper;
        }
        public async Task<List<SearchProduct1Dto>> Handle(SearchProduct1Query request, CancellationToken cancellationToken)
        {
            try
            {
                if (request.UserId <= 0 || request.UserId == null)
                {

                    throw new Exception("Invalid UserId");
                }
              
                
            }
            catch (Exception)
            {

                throw new Exception("Invalid UserId");
            }
            var searchFilter = await UnitOfWork.GetReposiotory<Product1>().GetListAsync(x => x.ItemNumber.ToString() == request.InputValue || x.CategoryId.ToString() == request.InputValue || x.Price.ToString() == request.InputValue || x.Id.ToString() == request.InputValue || x.CategoryId.ToString() == request.InputValue ||x.TypeOfPakcing==request.InputValue ||x.Description==request.InputValue);
          if(searchFilter != null) {
            var result=searchFilter.Take(50).ToList();
            var responce=Mapper.Map<List<SearchProduct1Dto>>(result);
            return responce;
            }
            throw new Exception("Not Found");
        }
    }
}
