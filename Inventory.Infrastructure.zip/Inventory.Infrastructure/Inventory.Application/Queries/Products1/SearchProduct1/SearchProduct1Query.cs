﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalWork.Application.Queries.Products1.SearchProduct1
{
    public class SearchProduct1Query : IRequest<List<SearchProduct1Dto>>
    {
      public string? InputValue { get; set; }
        public string? AccssToken { get; set; }
        public int UserId { get;set; }   
    }
}
