﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalWork.Application.Queries.Categories.GetAllCatagories
{
    public class GetAllCategoriesQuery :IRequest<List<CategoriesDto>>
    {
        public int? UserId { get; set; }
        public string? AccessToken { get; set; }
        public int Id { get; set; }
    }
}
