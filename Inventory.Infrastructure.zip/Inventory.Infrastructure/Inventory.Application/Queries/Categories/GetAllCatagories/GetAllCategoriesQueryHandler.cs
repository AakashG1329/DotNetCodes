﻿using AutoMapper;
using MediatR;
using PersonalWork.Application.Abstractions.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PersonalWork.Application.Queries.Categories.GetAllCatagories
{
    public class GetAllCategoriesQueryHandler : IRequestHandler<GetAllCategoriesQuery, List<CategoriesDto>>
    {
        public IUnitOfWork UnitOfWork;
        public IMapper mapper;
        public GetAllCategoriesQueryHandler(IUnitOfWork UnitOfWork, IMapper mapper) {
            this.UnitOfWork = UnitOfWork;
            this.mapper = mapper;
                }
        public Task<List<CategoriesDto>> Handle(GetAllCategoriesQuery request, CancellationToken cancellationToken)
        {
            throw new Exception("d") ;
        }
    }
}
