﻿using Microsoft.AspNetCore.Mvc;
using PersonalWork.API.Controllers;
using PersonalWork.Application.Queries.Products1.GetProduct1;

namespace PersonalWork.Api.Controllers
{
    public class CategoriesController :BaseController
    {
        [HttpPost("GetAllCategories")]
        public async Task<IActionResult> GetAll(int UserId, string AccessToken)
      => Ok(await Mediator.Send(new GetProduct1AllQuery { UserId = UserId, AccessToken = AccessToken }));
    }
}
